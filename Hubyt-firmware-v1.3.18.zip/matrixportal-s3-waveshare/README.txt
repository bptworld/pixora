Hubyt firmware v1.3.18 - matrixportal-s3-waveshare

This is a generic setup-page firmware image.

Files:
- merged_firmware.bin: first USB flash image
- firmware.bin: Wi-Fi update image after Hubyt is already installed
- bootloader.bin, partition-table.bin, flash_args: advanced/manual flashing files

No personal Wi-Fi, password, endpoint, or device name is baked into this build.

After first flash, configure the device from the Hubyt Windows app.
